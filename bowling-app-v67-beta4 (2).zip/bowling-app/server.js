const path = require('path');
const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve the static app folder at the site root
const appDir = path.join(__dirname, 'bowling-tool');
app.use(express.static(appDir, { extensions: ['html'] }));

// Default route
app.get('/', (_req, res) => {
  res.sendFile(path.join(appDir, 'index.html'));
});

// Helpful healthcheck
app.get('/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
